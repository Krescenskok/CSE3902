﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint0.Items;
using Sprint0.Link;

namespace Sprint0
{
    public class KeyboardController : IController
    {
        LinkPlayer linkPlayer;
        bool goingForward;

        LinkCommand linkCommand;
        ItemsCommand itemsCommand;

        public Items.LinkItems items;

        //LinkItems item;

        IDictionary<Keys, ICommand> commandsList = new Dictionary<Keys, ICommand>();
        SpriteBatch spriteBatch;

        public KeyboardController(LinkPlayer linkPlayer, LinkItems items)
        {
            this.linkPlayer = linkPlayer;
            this.linkCommand = new LinkCommand(linkPlayer);
            this.items = items;

        }

        public ICommand HandleInput(Game game)
        {
            var kstate = Keyboard.GetState();

            if (kstate.IsKeyDown(Keys.Q))
            {
                return new QuitCommand();
            }

            else if(kstate.IsKeyDown(Keys.U))
            {
                items.ChangeState(goingForward);
            }
           
            else if ((kstate.IsKeyDown(Keys.N)) || (kstate.IsKeyDown(Keys.Z)))
            {
                linkPlayer.IsAttacking = true;
                linkPlayer.IsStopped = false;
            }

            if (linkPlayer.IsAttacking)
                return linkCommand;

            else if ((kstate.IsKeyDown(Keys.A)) | (kstate.IsKeyDown(Keys.Left)))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingLeft();

            }
            else if ((kstate.IsKeyDown(Keys.D)) | (kstate.IsKeyDown(Keys.Right)))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingRight();

            }
            else if ((kstate.IsKeyDown(Keys.W)) | (kstate.IsKeyDown(Keys.Up)))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingUp();

            }
            else if ((kstate.IsKeyDown(Keys.S)) | (kstate.IsKeyDown(Keys.Down)))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingDown();
            }

            else if (kstate.IsKeyDown(Keys.E))
            {
                linkPlayer.IsDamaged = true;
            }
            else if (kstate.IsKeyDown(Keys.D1) || kstate.IsKeyDown(Keys.NumPad1))
            {
                linkPlayer.CurrentWeapon = Weapon.Sword;
            }

            else if (kstate.IsKeyDown(Keys.D2) || kstate.IsKeyDown(Keys.NumPad2))
            {
                linkPlayer.CurrentWeapon = Weapon.WoodenSword;
            }

            else if (kstate.IsKeyDown(Keys.D3) || kstate.IsKeyDown(Keys.NumPad3))
            {
                linkPlayer.CurrentWeapon = Weapon.MagicalRod;
            }

            else if (kstate.IsKeyDown(Keys.R))
            {
                linkPlayer.Stationary();
                linkPlayer.LocationInitialized = false;
            }
            return linkCommand;

        }
    }
}
