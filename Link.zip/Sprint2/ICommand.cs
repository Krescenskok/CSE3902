﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    public interface ICommand
    {
       

        void ExecuteCommand(Game game, GameTime gameTime, SpriteBatch spriteBatch);

        void Update(GameTime gameTime);
    }
}
