﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Sprint0
{
    public class MouseController : IController
    {
        

        public MouseController()
        {
        }

        public ICommand HandleInput(Game game)
        {
            MouseState state = Mouse.GetState();

            if (state.RightButton == ButtonState.Pressed)
                return new QuitCommand();

            return null;

        }
    }
}
