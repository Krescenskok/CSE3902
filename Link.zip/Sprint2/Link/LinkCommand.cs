﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class LinkCommand : ICommand
    {

        LinkPlayer linkPlayer;

        public LinkCommand(LinkPlayer linkPlayer)
        {
            this.linkPlayer = linkPlayer;
        }


        public void ExecuteCommand(Game game, GameTime gameTime, SpriteBatch spriteBatch)
        {
            linkPlayer.Draw(game, spriteBatch, gameTime );
        }

        public void Update(GameTime gameTime)
        {
            linkPlayer.Update(gameTime);
        }
    }
}
