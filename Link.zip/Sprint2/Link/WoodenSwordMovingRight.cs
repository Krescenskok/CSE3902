﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class WoodenSwordMovingRight:ILinkState
    {

        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;
        int MOVEMENT = 10;

        int currentFrame;

        public WoodenSwordMovingRight(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, currentFrame);
        }

        public void MovingDown()
        {
        }

        public void MovingLeft()
        {
            link.state = new WoodenSwordMovingLeft(link);
        }

        public void MovingRight()
        {
        }

        public void MovingUp()
        {
        }

        public void Stationary()
        {
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 200)
            {
                location.X += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (currentFrame == 26)
                {
                    currentFrame = 27;
                }
                else
                    currentFrame = 26;
                if (location.X >= 780)
                    location.X = 780;
            }

            return location;
        }

        public void WoodenSword()
        {
            link.state = new Stationary(link);
        }
    }
}
