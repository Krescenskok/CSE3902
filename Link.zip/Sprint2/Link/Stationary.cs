﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class Stationary: ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        public Stationary(LinkPlayer link)
        {
            this.link = link;
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        void ILinkState.Stationary()
        {

        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, 0, Color.White);
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            return location;
        }

        public void MovingRight()
        {
            link.state = new MovingRight(link);
        }

        public void MovingUp()
        {
            link.state = new MovingUp(link);
        }

        public void MovingDown()
        {
            link.state = new MovingDown(link);
        }

        public void Damaged()
        {
            link.state = new Damaged(link);
        }
    }
}
