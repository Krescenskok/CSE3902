﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class WoodenSwordMovingLeft: ILinkState
    {

        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;
        int MOVEMENT = 10;

        int currentFrame;

        public WoodenSwordMovingLeft(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, currentFrame);
        }

        public void MovingDown()
        {
        }

        public void MovingLeft()
        {
        }

        public void MovingRight()
        {
            link.state = new WoodenSwordMovingRight(link);
        }

        public void MovingUp()
        {
        }

        public void Stationary()
        {
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 200)
            {
                location.X += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (currentFrame == 4)
                    currentFrame = 5;
                else
                    currentFrame = 4;

                if (location.X <= 0)
                    location.X = 0;
            }



            return location;
        }

        public void WoodenSword()
        {
            link.state = new WoodenSword(link);
        }
    }
}
