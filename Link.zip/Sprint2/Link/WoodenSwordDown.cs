﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class WoodenSwordDown: ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;

        int currentFrame = 23;

      
    public WoodenSwordDown(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, currentFrame);
        }

        public void MagicalRodDown()
        {
            link.state = new MagicalRodDown(link);
        }

        public void MagicalRodLeft()
        {
            link.state = new MagicalRodLeft(link);
        }

        public void MagicalRodRight()
        {
            link.state = new MagicalRodRight(link);
        }

        public void MagicalRodUp()
        {
            link.state = new MagicalRodUp(link);
        }


        public void MovingDown()
        {
            link.state = new MovingDown(link);
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        public void MovingRight()
        {
            link.state = new MovingRight(link);
        }

        public void MovingUp()
        {
            link.state = new MovingUp(link);
        }

        public void Stationary()
        {
            link.state = new Stationary(link);
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
           

            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (currentFrame == 23)
                {
                    currentFrame = 22;
                }
                else if (currentFrame == 22)
                {
                    currentFrame = 21;
                }
                else if (currentFrame == 21)
                {
                    currentFrame = 20;
                }
                else
                {
                    currentFrame = 1;
                }

            }

            return location;
        }

        public void WoodenSwordRight()
        {
            link.state = new WoodenSwordRight(link);
        }

        void ILinkState.WoodenSwordDown()
        {
            link.state = new WoodenSwordDown(link);
        }
        public void WoodenSwordUp()
        {
            link.state = new WoodenSwordUp(link);
        }
        public void WoodenSwordLeft()
        {
            link.state = new WoodenSwordLeft(link);
        }
        public void Damaged()
        {
            link.state = new Damaged(link);
        }
        public void SwordDown()
        {
            link.state = new SwordDown(link);
        }

        public void SwordLeft()
        {
            link.state = new SwordLeft(link);
        }

        public void SwordRight()
        {
            link.state = new SwordRight(link);
        }

        public void SwordUp()
        {
            link.state = new SwordUp(link);
        }
    }
}
