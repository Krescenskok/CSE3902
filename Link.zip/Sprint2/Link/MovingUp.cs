﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class MovingUp: ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;
        int MOVEMENT = -10;

        int currentFrame;

        public MovingUp(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, currentFrame, Color.White);
        }

        public void MovingDown()
        {
            link.state = new MovingDown(link);

        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        public void MovingRight()
        {
            link.state = new MovingRight(link);
        }
  
        public void Stationary()
        {
            link.state = new Stationary(link);
        }

        public Vector2 HandleShield(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                location.Y += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;


                if (currentFrame == 6)
                {
                    currentFrame = 7;
                }
                else
                    currentFrame = 6;
                if (location.Y <= 0)
                    location.Y = 0;
            }
            link.IsAttacking = false;

            return location;
        }


        public Vector2 HandleWoodenSword(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 6:
                    case 7: currentFrame = 35; break;
                    case 35: currentFrame = 34; break;
                    case 34: currentFrame = 33; break;
                    case 33: currentFrame = 32; break;
                    case 32:
                        currentFrame = 6;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }

     
    public Vector2 HandleSword(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 6:
                    case 7: currentFrame = 57; break;
                    case 57: currentFrame = 56; break;
                    case 56: currentFrame = 55; break;
                    case 55: currentFrame = 54; break;
                    case 54:
                        currentFrame = 6;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }

    public Vector2 HandleMagicalRod(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 6:
                    case 7: currentFrame = 89; break;
                    case 89: currentFrame = 88; break;
                    case 88: currentFrame = 87; break;
                    case 87: currentFrame = 86; break;
                    case 86:
                        currentFrame = 6;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }


        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            if (link.IsStopped)
                return location;

            if (link.IsAttacking)
            {
                if (link.CurrentWeapon == Weapon.WoodenSword)
                {
                    return HandleWoodenSword(gameTime, location);
                }
                else if (link.CurrentWeapon == Weapon.Sword)
                {
                    return HandleSword(gameTime, location);
                }
                else if (link.CurrentWeapon == Weapon.MagicalRod)
                {
                    return HandleMagicalRod(gameTime, location);
                }

            }
            return HandleShield(gameTime, location);
        }

        void ILinkState.MovingUp()
        {
        }
        public void Damaged()
        {
            link.state = new Damaged(link);
        }
    }
}
