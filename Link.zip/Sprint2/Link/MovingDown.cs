﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class MovingDown: ILinkState
    {
        private LinkPlayer link;
        ISprite linkSprite;

        double lastTime = 0;
        int MOVEMENT = 10;

        int currentFrame;

        int timer = 100;
       
        
        public MovingDown(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            Color[] colors = { Color.Blue, Color.Yellow, Color.Pink, Color.Green, Color.Gold, Color.IndianRed, Color.Indigo, Color.Ivory };
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            if (link.IsDamaged)
            {
                int i = 0;
                Color col = colors[i];
                linkSprite.Draw(spriteBatch, gameTime, location, currentFrame, col);
                i++;
                if(i == colors.Length-1)
                {
                    i = 0;
                }
                    
                
            }
            else
            {
                linkSprite.Draw(spriteBatch, gameTime, location, currentFrame, Color.White);
            }
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        public void MovingRight()
        {
            link.state = new MovingRight(link);
        }

        public void MovingUp()
        {
            link.state = new MovingUp(link);
        }

        public void Stationary()
        {
            link.state = new Stationary(link);
        }


        public Vector2 HandleShield(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                location.Y += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;


                if (currentFrame == 0)
                {
                    currentFrame = 1;
                }
                else
                    currentFrame = 0;
                if (location.Y >= 445)
                    location.Y = 445;
            }
            link.IsAttacking = false;

            return location;
        }

        public Vector2 HandleWoodenSword(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 0:
                    case 1: currentFrame = 23; break;
                    case 23: currentFrame = 22; break;
                    case 22: currentFrame = 21; break;
                    case 21: currentFrame = 20; break;
                    case 20: currentFrame = 1;
                    link.IsAttacking = false;
                    link.IsStopped = true;
                    break;
                }
            }

            return location;
        }

        public Vector2 HandleSword(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 0:
                    case 1: currentFrame = 45; break;
                    case 45: currentFrame = 44; break;
                    case 44: currentFrame = 43; break;
                    case 43: currentFrame = 42; break;
                    case 42: currentFrame = 1;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }

        
        public Vector2 HandleMagicalRod(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 0:
                    case 1: currentFrame = 77; break;
                    case 77: currentFrame = 76; break;
                    case 76: currentFrame = 75; break;
                    case 75: currentFrame = 74; break;
                    case 74:
                        currentFrame = 1;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }

        public Vector2 Damaged(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                location.Y += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;


                if (currentFrame == 0)
                {
                    currentFrame = 1;
                }
                else
                    currentFrame = 0;
                if (location.Y >= 445)
                    location.Y = 445;
            }
            link.IsAttacking = false;

            return location;
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
   
            if (link.IsStopped)
                return location;

            if (link.IsDamaged)
            {
                timer--;
                if(timer>0)
                {
                    return Damaged(gameTime, location);
                }
                else
                {
                    link.IsDamaged = false;
                    return HandleShield(gameTime, location);
                }
            }

            if (link.IsAttacking)
            {
                if (link.CurrentWeapon == Weapon.WoodenSword)
                {
                    return HandleWoodenSword(gameTime, location);
                }
                else if (link.CurrentWeapon == Weapon.Sword)
                {
                    return HandleSword(gameTime, location);
                }
                else if (link.CurrentWeapon == Weapon.MagicalRod)
                {
                    return HandleMagicalRod(gameTime, location);
                }

            }
           
            return HandleShield(gameTime, location);
        }

        void ILinkState.MovingDown()
        {
        }
 
        public void Damaged()
        {
            link.state = new Damaged(link);
        }

    }
}
