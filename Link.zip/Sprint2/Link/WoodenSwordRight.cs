﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class WoodenSwordRight : ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;

        int currentFrame = 27;


        public WoodenSwordRight(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, currentFrame);
        }

        public void MovingDown()
        {
            link.state = new MovingDown(link);
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        public void MovingRight()
        {
            link.state = new MovingRight(link);
        }

        public void MovingUp()
        {
            link.state = new MovingUp(link);
        }

        public void Stationary()
        {
            link.state = new Stationary(link);
        }


        public Vector2 Update(GameTime gameTime, Vector2 location)
        {


            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (currentFrame == 27)
                {
                    currentFrame = 26;
                }
                else if (currentFrame == 26)
                {
                    currentFrame = 25;
                }
                else if (currentFrame == 25)
                {
                    currentFrame = 24;
                }
                else
                {
                    currentFrame = 2;
                }

            }

            return location;
        }

        public void Damaged()
        {
            link.state = new Damaged(link);
        }
  
    }
}
