﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class MovingRight: ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;
        int MOVEMENT = 10;

        int currentFrame;

        public MovingRight(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

                linkSprite.Draw(spriteBatch, gameTime, location, currentFrame, Color.White);
        }

        public void MovingDown()
        {
            link.state = new MovingDown(link);
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        public void MovingUp()
        {
            link.state = new MovingUp(link);
        }

        public void Stationary()
        {
            link.state = new Stationary(link);
        }


        public Vector2 HandleShield(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                location.X += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (currentFrame == 2)
                {
                    currentFrame = 3;
                }
                else
                    currentFrame = 2;
                if (location.X >= 780)
                    location.X = 780;
            }
            link.IsAttacking = false;
            return location;
        }
      
       
    public Vector2 HandleWoodenSword(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;
                switch (currentFrame)
                {
                    case 2:
                    case 3: currentFrame = 27; break;
                    case 27: currentFrame = 26; break;
                    case 26: currentFrame = 25; break;
                    case 25: currentFrame = 24; break;
                    case 24:
                        currentFrame = 2;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }

    
    public Vector2 HandleSword(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 2:
                    case 3: currentFrame = 49; break;
                    case 49: currentFrame = 48; break;
                    case 48: currentFrame = 47; break;
                    case 47: currentFrame = 46; break;
                    case 46:
                        currentFrame = 2;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }

    
    public Vector2 HandleMagicalRod(GameTime gameTime, Vector2 location)
        {
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                switch (currentFrame)
                {
                    case 2:
                    case 3: currentFrame = 81; break;
                    case 81: currentFrame = 80; break;
                    case 80: currentFrame = 79; break;
                    case 79: currentFrame = 78; break;
                    case 78:
                        currentFrame = 2;
                        link.IsAttacking = false;
                        link.IsStopped = true;
                        break;
                }
            }

            return location;
        }


        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            if (link.IsStopped)
                return location;

            if (link.IsAttacking)
            {
                if (link.CurrentWeapon == Weapon.WoodenSword)
                {
   
                    return HandleWoodenSword(gameTime, location);
                }
                else if (link.CurrentWeapon == Weapon.Sword)
                {
                    return HandleSword(gameTime, location);
                }
                else if (link.CurrentWeapon == Weapon.MagicalRod)
                {
                    return HandleMagicalRod(gameTime, location);
                }
            }
            return HandleShield(gameTime, location);
        }

        void ILinkState.MovingRight()
        {
        }
        public void Damaged()
        {
            link.state = new Damaged(link);
        }
    }
}
