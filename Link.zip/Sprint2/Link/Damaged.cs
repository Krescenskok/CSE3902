﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class Damaged: ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;

        int currentFrame = 101;
        int timer = 1000;

        public Damaged(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, currentFrame, Color.White);
        }

        public void MovingDown()
        {
            link.state = new MovingDown(link);
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        public void MovingRight()
        {
            link.state = new MovingRight(link);
        }

        public void MovingUp()
        {
            link.state = new MovingUp(link);
        }

        public void Stationary()
        {
            link.state = new Stationary(link);
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            timer--;

            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 100)
            {
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (timer > 0)
                {
                    currentFrame++;
                    if (currentFrame == 126)
                    {
                        currentFrame = 101;
                    }
                }
                else
                {
                    currentFrame = 1;
                }

            }

            return location;
        }

        void ILinkState.Damaged()
        {
            link.state = new Damaged(link);
        }
    }
}
