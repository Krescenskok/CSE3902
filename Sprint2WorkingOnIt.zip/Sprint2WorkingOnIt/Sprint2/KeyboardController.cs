﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint0.Items;
using Sprint0.Link;

namespace Sprint0
{
   
    public class KeyboardController: IController
    {
        
        IDictionary<Keys, ICommand> commandsList = new Dictionary<Keys, ICommand>();

        SpriteBatch spriteBatch;

        public KeyboardController(SpriteBatch spriteBatch, Game1 game)
        {
            
            this.spriteBatch = spriteBatch;
            commandsList.Add(Keys.Q, new QuitCommand());

   

            commandsList.Add(Keys.A, new LinkCommand(new LinkPlayer(), "A"));
            commandsList.Add(Keys.Left, new LinkCommand(new LinkPlayer(), "Left"));
            commandsList.Add(Keys.D, new LinkCommand(new LinkPlayer(), "D"));
            commandsList.Add(Keys.Right, new LinkCommand(new LinkPlayer(), "Right"));
            commandsList.Add(Keys.W, new LinkCommand(new LinkPlayer(), "W"));
            commandsList.Add(Keys.Up, new LinkCommand(new LinkPlayer(), "Up"));
            commandsList.Add(Keys.S, new LinkCommand(new LinkPlayer(), "S"));
            commandsList.Add(Keys.Down, new LinkCommand(new LinkPlayer(), "Down"));
            commandsList.Add(Keys.N, new LinkCommand(new LinkPlayer(), "N"));
            commandsList.Add(Keys.Z, new LinkCommand(new LinkPlayer(), "Z"));
            commandsList.Add(Keys.E, new LinkCommand(new LinkPlayer(), "E"));
            commandsList.Add(Keys.D1, new LinkCommand(new LinkPlayer(), "D1"));
            commandsList.Add(Keys.NumPad1, new LinkCommand(new LinkPlayer(), "NumPad1"));
            commandsList.Add(Keys.D2, new LinkCommand(new LinkPlayer(), "D2"));
            commandsList.Add(Keys.NumPad2, new LinkCommand(new LinkPlayer(), "NumPad2"));
            commandsList.Add(Keys.D3, new LinkCommand(new LinkPlayer(), "D3"));
            commandsList.Add(Keys.NumPad3, new LinkCommand(new LinkPlayer(), "NumPad3"));
            commandsList.Add(Keys.R, new LinkCommand(new LinkPlayer(), "R"));

            commandsList.Add(Keys.U, new ItemsCommand(spriteBatch, game.items, true, false));
            commandsList.Add(Keys.I, new ItemsCommand(spriteBatch, game.items, true, true));

        }

        public List<ICommand> HandleInput(Game1 game)
        {
            
            List<ICommand> commandList = new List<ICommand>();
 
            var kstate = Keyboard.GetState();
            foreach (KeyValuePair<Keys, ICommand> kvp in commandsList)
            {
                if (kstate.IsKeyDown(kvp.Key))
                {
                   
                    if ((kvp.Key.Equals("U")) || (kvp.Key.Equals("I")) || (kvp.Key.Equals("Q")) )
                    {
                        commandList.Add(kvp.Value);
                    } else
                    {
                        game.linkCommand = kvp.Value;
                    }
                    
                    
                    
                }
            }
            

            return commandList;
        }

    }
}
