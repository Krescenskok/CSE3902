﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items
{
    public class Items
    {
        private SpriteBatch SpriteBatch;
        private ItemsStateMachine StateMachine;
        private ItemsStateMachine PrevState;
        private bool GoingForward;
        
        public Items(SpriteBatch spriteBatch, bool goingForward)
        {
            this.SpriteBatch = spriteBatch;
            this.GoingForward = goingForward;
            StateMachine = new ItemsStateMachine(goingForward);
            PrevState = StateMachine;
        }

        public void Draw()
        {
            StateMachine.Draw(SpriteBatch);
        }

        public void ChangeState(bool goingForward)
        {
            StateMachine.ChangeItem(goingForward);
        }


        public void Update()
        {
            StateMachine.Update();
        }

        /*public void Map()
        {

        }

        public void Key()
        {

        }

        public void FancyKey()
        {

        }

        public void HeartContainer()
        {

        }

        public void TriforcePiece()
        {

        }

        public void WoodenBoomerang()
        {

        }

        public void Bow()
        {

        }

        public void FullHeart()
        {

        }

        public void HalfHeart()
        {

        }

        public void EmptyHeart()
        {

        }

        public void Rupee()
        {

        }

        public void Arrow()
        {

        }

        public void Bomb()
        {

        }

        public void Fairy()
        {

        }

        public void Clock()
        {

        }

        public void Meat()
        {

        }

        public void MagicBook()
        {

        }

        public void Recorder()
        {

        }*/
    }
}
