﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;

namespace Sprint0
{
    interface IController
    {
        public List<ICommand> HandleInput(Game1 game);
        
    }
}
