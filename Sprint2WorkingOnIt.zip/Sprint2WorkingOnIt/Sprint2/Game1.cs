﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint0.Items;
using Sprint0.Link;

namespace Sprint0
{

    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch spriteBatch;
        private SpriteFont font;
        public  Items.Items items;

        List<IController> controllers = new List<IController>();

        List<ICommand> activeCommands = new List<ICommand>();

        public ICommand linkCommand;

        LinkPlayer linkPlayer = new LinkPlayer();


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {

            base.Initialize();
        }

        protected override void LoadContent()
        {

            font = Content.Load<SpriteFont>("File");

            SpriteFactory.Instance.LoadAllTextures(Content);
         
            spriteBatch = new SpriteBatch(GraphicsDevice);

          

            items = new Items.Items(spriteBatch, true);

            controllers.Add(new KeyboardController(spriteBatch, this));

            linkCommand = new LinkCommand(linkPlayer, "");
            activeCommands.Add(linkCommand);


        }

        protected override void Update(GameTime gameTime)
        {
            int i;
            ICommand[] activeArray;
            foreach (var cont in controllers)
            {

                activeCommands = cont.HandleInput(this);
                

            }

            activeCommands.Add(new ItemsCommand(spriteBatch, this.items, false, false));
            activeArray = activeCommands.ToArray();
            i = 0;

            while (i < activeArray.Length)
            {
                activeArray[i].Update(gameTime);
                i++;
            }

            linkCommand.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {

            GraphicsDevice.Clear(Color.CornflowerBlue);
            /*
            _spriteBatch.DrawString(font, "Credits", new Vector2(250, 300), Color.Black);
            _spriteBatch.DrawString(font, "Program made by: Krescens Kok", new Vector2(250, 320), Color.Black);
            _spriteBatch.DrawString(font, "Sprites from: http://www.mariouniverse.com/", new Vector2(250, 340), Color.Black);
            _spriteBatch.DrawString(font, "wp-content/img/sprites/nes/smb/mario.png", new Vector2(250, 360), Color.Black);

            */
            int i;

            ICommand[] activeArray = activeCommands.ToArray();
            i = 0;
            while (i < activeArray.Length)
            {
                activeArray[i].ExecuteCommand(this, gameTime, spriteBatch);
                i++;
            }

            activeCommands.Clear();


            //linkCommand.ExecuteCommand(this, spriteBatch);
            //itemCommand.ExecuteCommand(this, spriteBatch);
            /* if (activeCommand != null)
             {
                 activeCommand.ExecuteCommand(this, spriteBatch);
             }
            */
            base.Draw(gameTime);
        }
    }
}
