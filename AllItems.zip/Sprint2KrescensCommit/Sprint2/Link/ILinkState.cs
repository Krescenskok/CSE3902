﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public interface ILinkState
    {
        void Stationary();
        void MovingLeft();
        Vector2 Update(GameTime gameTime, Vector2 location);
        void Draw(SpriteBatch spriteBatch, Vector2 location);

    }
}
