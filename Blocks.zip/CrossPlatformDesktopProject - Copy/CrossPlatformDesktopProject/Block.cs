﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossPlatformDesktopProject
{
    class Block : IBlock
    {

		public Texture2D Texture { get; set; }
		public int Rows { get; set; }
		public int Columns { get; set; }
		private int currentFrame;
		private int totalFrames;

		public Block(Texture2D texture)
		{
			Texture = texture;
			Columns = 4;
			Rows = 3;
			totalFrames = 9;
			currentFrame = 0;
		}
		
		public void Update(int direction)
		{
			if (direction == 2)
			{
				if (currentFrame >= totalFrames)
				{
					currentFrame = 0;
				}
				else
				{
					currentFrame++;
				}
			}
			else if (direction == 1)
			{
				if (currentFrame <= 0)
				{
					currentFrame = totalFrames;
				}
				else
				{
					currentFrame--;
				}
			}
		}
		public void Draw(SpriteBatch spriteBatch, Vector2 location)
		{
			Rectangle sourceRectangle;
			Rectangle destinationRectangle;

			int width = Texture.Width / Columns;
			int height = Texture.Height / Rows;
			int row = (int)((float)currentFrame / (float)Columns);
			int column = currentFrame % Columns;

			sourceRectangle = new Rectangle(width * column, height * row, width, height);
			destinationRectangle = new Rectangle((int)location.X, (int)location.Y, 150, 150);

			spriteBatch.Begin();
			spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
			spriteBatch.End();
		}
	}
}
