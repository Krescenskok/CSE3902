﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace CrossPlatformDesktopProject
{
    interface IBlock
    {
        void Draw(SpriteBatch spriteBatch, Vector2 location);

        void Update(int direction);

    }
}
