﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrossPlatformDesktopProject
{
    class MouseControl : IController
    {
        public int current;
        public MouseControl()
        {
            current = 1;
        }
        public int update(int width, int height)
        {

            MouseState state = Mouse.GetState();

            if (state.RightButton == ButtonState.Pressed)
            {
                current = 0;
            }
            else if (state.LeftButton == ButtonState.Pressed)
            {
                if(state.Position.X < width/2 && state.Position.Y < height/ 2)
                {
                    current = 1;
                }
                else if (state.Position.X >= width / 2 && state.Position.Y < height / 2)
                {
                    current = 2;
                }
                else if (state.Position.X < width/2 && state.Position.Y >= height / 2)
                {
                    current = 3;
                }
                else if (state.Position.X >= width / 2 && state.Position.Y >= height / 2)
                {
                    current = 4;
                }
            }

            return current;
        }
    }
}
