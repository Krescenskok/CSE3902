﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Net.Mime;
namespace CrossPlatformDesktopProject
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game2 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private Vector2 spritePos;
        private Texture2D donkey;
        KeyboardControl keyboard;
        private Block block;
        int keyboardCurrent, delay;

        public Game2()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {

            base.Initialize();
        }

        protected override void LoadContent()
        {

            spriteBatch = new SpriteBatch(GraphicsDevice);

            donkey = Content.Load<Texture2D>("CharacterSprites/zelda_tiles_focused");
            block = new Block(donkey);
            keyboard = new KeyboardControl();
            keyboardCurrent = 0;
            delay = 1;


            spritePos = new Vector2(graphics.GraphicsDevice.Viewport.Width / 2,
        graphics.GraphicsDevice.Viewport.Height / 2);

        }


        protected override void UnloadContent()
        {

        }


        protected override void Update(GameTime gameTime)
        {
            keyboardCurrent = keyboard.update(0, 0);

            if (delay % 8 == 0) { 
                block.Update(keyboardCurrent);
                delay = 1;
            }else{
                delay++;
            }
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {

            GraphicsDevice.Clear(Color.White);

            block.Draw(spriteBatch, spritePos);

            base.Draw(gameTime);

        }
    }
}


