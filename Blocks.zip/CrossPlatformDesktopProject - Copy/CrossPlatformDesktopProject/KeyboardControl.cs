﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;

namespace CrossPlatformDesktopProject
{
    class KeyboardControl : IController
    {
        public int current;
        public KeyboardControl()
        {
        }
        public int update(int x, int y)
        {

            KeyboardState state = Keyboard.GetState();

            if (state.IsKeyDown(Keys.T)) {
                current = 1;
            }
            else if(state.IsKeyDown(Keys.Y)){
                current = 2;
            }
            else
            {
                current = 0;
            }

            return current;
        }
    }
}
