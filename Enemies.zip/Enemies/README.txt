Hi Andrew or possibly someone else,

These are all the enemy classes me and Yuan have done. To toggle between them, just add the two ICommands, DisplayNextEnemy and DisplayPreviousEnemy to the KeyboardController. Then, add the following lines to the main game class:

----In the LoadContent method---- 

EnemySpriteFactory.Instance.LoadAllTextures(this);
EnemyNPCDisplay.Instance.Load(this, new Vector2, new Vector2);


----In the Update method---- 

EnemyNPCDisplay.Instance.Update();


----In the Draw method---- 

EnemyNPCDisplay.Instance.Draw(_spriteBatch, gameTime);

Best,
JT