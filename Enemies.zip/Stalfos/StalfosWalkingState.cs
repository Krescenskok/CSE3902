﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint0
{
    class StalfosWalkingState : IEnemyState
    {

        private Stalfos skeleton;
        private Vector2 location;

        private Vector2 walkingDirection;
        private int[] directionModifier;

        private List<Stalfos.direction> possibleDirections;

        private const float moveSpeed = 2;

        

        public StalfosWalkingState(Stalfos stalfos, Vector2 location)
        {
            skeleton = stalfos;

            this.location = location;


            stalfos.SetSprite(EnemySpriteFactory.Instance.CreateStalfosWalkingSprite());

            walkingDirection.X = 1;
            walkingDirection.Y = 0;

            directionModifier = new int[2];
            directionModifier[0] = -1;
            directionModifier[1] = 1;

            
        }

        public void Attack()
        {
            //do nothing
        }

        public void ChangeDirection()
        {
            possibleDirections = skeleton.GetDirections();
            
            
            Random rand = new Random();
            Stalfos.direction nextDirection = possibleDirections[rand.Next(0, possibleDirections.Count)];

            skeleton.UpdateDirection(nextDirection);

            
            if(nextDirection == Stalfos.direction.left)
            {
                walkingDirection.X = -1;
                walkingDirection.Y = 0;
            }
            else if(nextDirection == Stalfos.direction.right)
            {
                walkingDirection.X = 1;
                walkingDirection.Y = 0;
            }
            else if (nextDirection == Stalfos.direction.up)
            {
                walkingDirection.X = 0;
                walkingDirection.Y = 1;
            }
            else if (nextDirection == Stalfos.direction.down)
            {
                walkingDirection.X = 0;
                walkingDirection.Y = -1;
            }

        }

        public void Die()
        {
            //change to dying state
        }

        public Vector2 GetLocation()
        {
            return location;
        }

        public void TakeDamage()
        {
            //subtract from health
            //call Die() if health < 0
        }

        public void Update()
        {
            //check if on walkable tile and change direction if necessary

            MoveOneUnit();

        }

        public void MoveOneUnit()
        {
            location.X += walkingDirection.X * moveSpeed;
            location.Y +=  walkingDirection.Y * moveSpeed;
            skeleton.UpdateLocation(location);
        }

        public void MoveBack()
        {
            location.X -= walkingDirection.X * moveSpeed;
            location.Y -= walkingDirection.Y * moveSpeed;
        }
    }
}
