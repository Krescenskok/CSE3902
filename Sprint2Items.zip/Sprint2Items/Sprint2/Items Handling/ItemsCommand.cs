﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items
{
    class ItemsCommand : ICommand
    {
        Items items;
        bool GoingForward;

        public ItemsCommand(SpriteBatch spriteBatch,Items items, bool goingForward)
        {
            this.GoingForward = goingForward;
            this.items = items;
        }

        public void DoInit(Game game)
        {
            SwapItem(game);
            //throw new NotImplementedException();
        }

        public void ExecuteCommand(Game game, SpriteBatch spriteBatch)
        {

            items.Draw();
        }

        public void Update(GameTime GameTime)
        {
            items.Update();
        }
        
        public void SwapItem(Game game)
        {
            items.ChangeState(this.GoingForward);
        }
    }
}

