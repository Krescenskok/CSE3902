﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint0.Items;
using Sprint0.Link;

namespace Sprint0
{
    public class KeyboardController: IController
    {

        IDictionary<Keys, ICommand> commandsList = new Dictionary<Keys, ICommand>();
        SpriteBatch spriteBatch;

        public KeyboardController(SpriteBatch spriteBatch, Game1 game)
        {
            
            this.spriteBatch = spriteBatch;
            commandsList.Add(Keys.Q, new QuitCommand());
            commandsList.Add(Keys.A, new LinkCommand(new LinkPlayer()));
            commandsList.Add(Keys.U, new ItemsCommand(spriteBatch, game.items, false));
            commandsList.Add(Keys.I, new ItemsCommand(spriteBatch, game.items, true));

        }

        public ICommand HandleInput(Game1 game)
        {

            var kstate = Keyboard.GetState();

            foreach (KeyValuePair<Keys, ICommand> kvp in commandsList)
            {
                if (kstate.IsKeyDown(kvp.Key))
                {

                    return kvp.Value;
                }
            }

            return null;
        }
    }
}
