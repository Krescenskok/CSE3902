﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class LinkCommand : ICommand
    {

        LinkPlayer linkPlayer;

        public LinkCommand(LinkPlayer linkPlayer)
        {
            this.linkPlayer = linkPlayer;
        }

        public void DoInit(Game game)
        {
            //throw new NotImplementedException();
        }

        public void ExecuteCommand(Game game, SpriteBatch spriteBatch)
        {
            linkPlayer.Draw(game, spriteBatch );
        }

        public void Update(GameTime gameTime)
        {
            linkPlayer.Update(gameTime);
        }
    }
}
