﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint2
{
    /// <summary>
    /// Author: Yuan Hong
    /// </summary>
    class AquamentusDieState : IEnemyState
    {
        public AquamentusDieState()
        {

        }

        public void Attack()
        {
            throw new NotImplementedException();
        }

        public void ChangeDirection()
        {
            throw new NotImplementedException();
        }

        public void Die()
        {
            throw new NotImplementedException();
        }


        public void TakeDamage()
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
