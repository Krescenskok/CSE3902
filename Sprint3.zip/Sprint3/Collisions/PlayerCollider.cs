﻿using Microsoft.Xna.Framework;
using Sprint2;
using Sprint2.Link;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint2Final
{
    public class PlayerCollider : ICollider
    {
        private Rectangle bounds;
        //private ILinkState state;
        private float damageAmount;
        LinkPlayer linkPlayer;
        String Key;

        public PlayerCollider(LinkPlayer linkPlayer)
        {

            this.linkPlayer = linkPlayer;

        }

        public Rectangle Bounds()
        {

            return linkPlayer.Bounds;
        }

        public bool CompareTag(string tag)
        {
            return tag == "Player" || tag == "player";
        }

        public bool Equals(ICollider col)
        {
            return this == col;
        }

        public void HandleCollision(ICollider col, Collision collision)
        {


            System.Diagnostics.Debug.WriteLine("COLLISSION");

            if (collision != null) { 
            if (collision.Left())
            {

            }
        }
            //if (Key.Equals("N") || Key.Equals("Z")) {

            //    if (!linkPlayer.IsAttacking && col.CompareTag("Enemy") && (collision.Right() || collision.Left() || collision.Up() || collision.Down()))
            //    {
            //        col.SendMessage("TakeDamage", damageAmount);
            //    }
            //}

        }

        public void SendMessage(string msg, object value)
        {
            if (msg == "PlayerTakeDamage")
            {
                linkPlayer.IsDamaged = true;
            }
        
        }
    }
}
