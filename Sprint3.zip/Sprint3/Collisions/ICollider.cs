﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint2Final
{
    public interface ICollider
    {
        //figure out what the other collider is
        bool CompareTag(string tag);
        //checks if collider is equal to each other
        bool Equals(ICollider col);
        //takeDamage
        void SendMessage(string msg, object value);

        Rectangle Bounds();

        
        void HandleCollision(ICollider col, Collision collision);
  

        
    }
}
