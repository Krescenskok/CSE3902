﻿using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    public class DisplayAnimatedSpriteAtFixedPositionCommand : ICommand
    {
        private AnimatedSprite sprite = new AnimatedSprite();

        double lastTime = 0;

        public DisplayAnimatedSpriteAtFixedPositionCommand()
        {
        }

        public void DoInit(Game game)
        {
            sprite.Load(game);
        }


        public void Update(GameTime gameTime)
        {

            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 400)
            {
                sprite.CurrentFrame++;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;
            }
            
        }

        public void ExecuteCommand(Game game, GameTime gameTime, SpriteBatch spriteBatch)
        {
            Update(gameTime);
            sprite.Draw(spriteBatch, gameTime, new Vector2(game.GraphicsDevice.Viewport.Width / 2, game.GraphicsDevice.Viewport.Height / 2));
        }
    }
}
