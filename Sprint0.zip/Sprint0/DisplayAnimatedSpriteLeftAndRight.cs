﻿using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    public class DisplayNonAnimatedSpriteLeftAndRight : ICommand
    {
        private AnimatedSprite sprite = new AnimatedSprite();

        Vector2 location;
        double lastTime = 0;
        int movement = -10;

        public DisplayNonAnimatedSpriteLeftAndRight()
        {
        }

        public void DoInit(Game game)
        {
            sprite.Load(game);
            location = new Vector2(game.GraphicsDevice.Viewport.Width / 2, game.GraphicsDevice.Viewport.Height / 2);
        }

        public void Update(GameTime gameTime)
        {

            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 200)
            {
                location.X -= movement;
                sprite.CurrentFrame++;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;
            }

        }

        public void ExecuteCommand(Game game, GameTime gameTime, SpriteBatch spriteBatch)
        {
            Update(gameTime);

            if ((location.X >= game.GraphicsDevice.Viewport.Width))
            {
                location.X = 0;
            }

            sprite.Draw(spriteBatch, gameTime, location);

        }
    }
}
