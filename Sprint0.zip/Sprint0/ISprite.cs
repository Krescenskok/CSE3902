﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    interface ISprite
    {

        void Load(Game game);
        void Draw(SpriteBatch spriteBatch, GameTime gameTim, Vector2 vector);
    }
}
