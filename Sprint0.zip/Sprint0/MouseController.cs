﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Sprint0
{
    public class MouseController : IController
    {
        

        public MouseController()
        {
        }

        public ICommand HandleInput(Game game)
        {
            MouseState state = Mouse.GetState();

            if (state.RightButton == ButtonState.Pressed)
                return new QuitCommand();

            if ((state.LeftButton == ButtonState.Pressed) && (state.Position.X < game.GraphicsDevice.Viewport.Width / 2) && (state.Position.Y < game.GraphicsDevice.Viewport.Height / 2))
            {
                ICommand command = new DisplayNonAnimatedSpriteAtFixedPositionCommand();
                command.DoInit(game);
                return command;
            }
            if ((state.LeftButton == ButtonState.Pressed) && (state.Position.X > game.GraphicsDevice.Viewport.Width / 2) && (state.Position.Y < game.GraphicsDevice.Viewport.Height / 2))
            {
                ICommand command = new DisplayAnimatedSpriteAtFixedPositionCommand();
                command.DoInit(game);
                return command;
            }
            if ((state.LeftButton == ButtonState.Pressed) && (state.Position.X < game.GraphicsDevice.Viewport.Width / 2) && (state.Position.Y > game.GraphicsDevice.Viewport.Height / 2))
            {
                ICommand command = new DisplayNonAnimatedSpriteUpAndDown();
                command.DoInit(game);
                return command;
            }
            if ((state.LeftButton == ButtonState.Pressed) && (state.Position.X > game.GraphicsDevice.Viewport.Width / 2) && (state.Position.Y > game.GraphicsDevice.Viewport.Height / 2))
            {
                ICommand command = new DisplayNonAnimatedSpriteLeftAndRight();
                command.DoInit(game);
                return command;
            }


            return null;

        }
    }
}
