﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sprint0;

namespace Sprint0.Items
{

    public class ItemsSprite : ISprite
    {
        Texture2D texture;
        private Rectangle sourceRectangle;
        private Rectangle destinationRectangle;
        private int width = 10;
        private int height = 20;

        public ItemsSprite(Texture2D texture)
        {
            this.texture = texture;
            sourceRectangle = new Rectangle(0, 0, 10, 10);
            destinationRectangle = new Rectangle(50, 50, 100, 100);
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location, int currentFrame)
        {
            spriteBatch.Begin();
            sourceRectangle = new Rectangle((int) location.X, (int)location.Y, width, height);
            spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
        
    }
}
