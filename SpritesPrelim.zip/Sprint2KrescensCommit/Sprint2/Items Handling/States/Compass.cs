﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Sprint0.Items
{
    public class Compass : IItemsState
    {
        private Vector2 spriteLocation;
        private ISprite item;

        public Compass(ISprite item)
        {
            spriteLocation = new Vector2(71, 80);
            this.item = item;
        }

        public void Update()
        {
            //no animation - no update
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            item.Draw(spriteBatch, spriteLocation, 0);

        }

        public Vector2 GetLocation()
        {
            return spriteLocation;
        }

    }
}
