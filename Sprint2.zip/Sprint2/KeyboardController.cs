﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Sprint0.Link;

namespace Sprint0
{
    public class KeyboardController: IController
    {

        //IDictionary<Keys, ICommand> keysToCommands = new Dictionary<Keys, ICommand>();

        LinkPlayer linkPlayer;

        LinkCommand linkCommand;


        public KeyboardController(LinkPlayer linkPlayer)
        {


            this.linkPlayer = linkPlayer;
            this.linkCommand = new LinkCommand(linkPlayer);
            /*
            keysToCommands.Add(Keys.D0, new QuitCommand());
            keysToCommands.Add(Keys.NumPad0, new QuitCommand());


            keysToCommands.Add(Keys.D1, new DisplayNonAnimatedSpriteAtFixedPositionCommand());
            keysToCommands.Add(Keys.NumPad1, new DisplayNonAnimatedSpriteAtFixedPositionCommand());
            keysToCommands.Add(Keys.D2, new DisplayAnimatedSpriteAtFixedPositionCommand());
            keysToCommands.Add(Keys.NumPad2, new DisplayAnimatedSpriteAtFixedPositionCommand());
            keysToCommands.Add(Keys.D3, new DisplayNonAnimatedSpriteUpAndDown());
            keysToCommands.Add(Keys.NumPad3, new DisplayNonAnimatedSpriteUpAndDown());
            keysToCommands.Add(Keys.D4, new DisplayNonAnimatedSpriteLeftAndRight());
            keysToCommands.Add(Keys.NumPad4, new DisplayNonAnimatedSpriteLeftAndRight());


            foreach (KeyValuePair<Keys, ICommand> kvp in keysToCommands)
            {
                kvp.Value.DoInit(game);
            }*/
        }

        public ICommand HandleInput(Game game)
        {
            var kstate = Keyboard.GetState();

            if ((kstate.IsKeyDown(Keys.D0)) || (kstate.IsKeyDown(Keys.NumPad0)))
            {
                return new QuitCommand();
            }

            if ((kstate.IsKeyDown(Keys.A)))
            {
                linkPlayer.MoveLeft();
                return linkCommand;
            }


                /*
                foreach (KeyValuePair<Keys, ICommand> kvp in keysToCommands)
                {
                    if (kstate.IsKeyDown(kvp.Key))
                    {

                        return kvp.Value;
                    }
                }*/





                return null;

        }
    }
}
