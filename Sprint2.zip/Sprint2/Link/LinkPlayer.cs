﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class LinkPlayer
    {
        public ILinkState state;

        Boolean loc = false;
        Vector2 currentLocation;

        public LinkPlayer()
        {
            state = new Stationary(this);
        }

        public void Update(GameTime gameTime)
        {
            currentLocation =  state.Update(gameTime, currentLocation);
        }

        public void MoveLeft()
        {
            state.MovingLeft();
        }


        public void Draw(Game game, SpriteBatch spriteBatch, GameTime gameTime)
        {

            if (loc == false)
            {
                loc = true;
                currentLocation = new Vector2(game.GraphicsDevice.Viewport.Width / 2, game.GraphicsDevice.Viewport.Height / 2);
            }

            state.Draw(spriteBatch, gameTime, currentLocation);
        }
    }
}
