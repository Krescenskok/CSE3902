﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class Stationary: ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        public Stationary(LinkPlayer link)
        {
            this.link = link;
        }

        public void MovingLeft()
        {
            link.state = new MovingLeft(link);
        }

        void ILinkState.Stationary()
        {
            //throw new NotImplementedException();
        }


      

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();

            linkSprite.Draw(spriteBatch, gameTime, location, 0);

            //sprite.Draw(spriteBatch, gameTime, new Vector2(game.GraphicsDevice.Viewport.Width / 2, game.GraphicsDevice.Viewport.Height / 2));
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
            return location;
        }
    }
}
