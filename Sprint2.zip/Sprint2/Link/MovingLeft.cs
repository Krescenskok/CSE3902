﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Link
{
    public class MovingLeft : ILinkState
    {
        private LinkPlayer link;

        ISprite linkSprite;

        double lastTime = 0;
        int MOVEMENT = -10;

        int currentFrame = 7;

        public MovingLeft(LinkPlayer link)
        {
            this.link = link;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (linkSprite == null)
                linkSprite = SpriteFactory.Instance.CreateLinkSprite();


            
                linkSprite.Draw(spriteBatch, gameTime, location, currentFrame);
           
     

           
        }

        public void Stationary()
        {
            link.state = new Stationary(link);
        }

        public Vector2 Update(GameTime gameTime, Vector2 location)
        {
      
        
            if (gameTime.TotalGameTime.TotalMilliseconds - lastTime > 200)
            {
                location.X += MOVEMENT;
                lastTime = gameTime.TotalGameTime.TotalMilliseconds;

                if (currentFrame == 4)
                    currentFrame = 5;
                else
                    currentFrame = 4;

                if (location.X <= 0)
                    location.X = 0;
            }

            

            return location;

        }

        void ILinkState.MovingLeft()
        {
            //throw new NotImplementedException();
        }
    }
}
