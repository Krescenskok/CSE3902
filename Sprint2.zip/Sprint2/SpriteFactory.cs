﻿using System;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Sprint0.Link;

namespace Sprint0
{
    public class SpriteFactory
    {
        private Texture2D linkSpriteSheet;

        private static SpriteFactory instance = new SpriteFactory();

        public static SpriteFactory Instance
        {
            get
            {
                return instance;
            }
        }

        public SpriteFactory()
        {
        }

        public void LoadAllTextures(ContentManager content)
        {
            linkSpriteSheet = content.Load<Texture2D>("LinkSpriteSheet");
        }

        public ISprite CreateLinkSprite()
		{
            return new LinkSprite(linkSpriteSheet);
		}
		
    }
}
