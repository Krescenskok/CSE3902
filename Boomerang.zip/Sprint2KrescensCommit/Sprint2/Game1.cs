﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint0.Items;
using Sprint0.Link;

namespace Sprint0
{

    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch spriteBatch;
        private SpriteFont font;

        List<IController> controllers = new List<IController>();

        ICommand linkCommand;
        ICommand itemCommand;

        LinkPlayer linkPlayer = new LinkPlayer();

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {

            font = Content.Load<SpriteFont>("File");

            SpriteFactory.Instance.LoadAllTextures(Content);
         
            spriteBatch = new SpriteBatch(GraphicsDevice);

            controllers.Add(new KeyboardController(spriteBatch));

            linkCommand = new LinkCommand(linkPlayer);
            linkCommand.DoInit(this);
            itemCommand = new ItemsCommand(spriteBatch, true);
            itemCommand.DoInit(this);

        }

        protected override void Update(GameTime gameTime)
        {

            foreach (var cont in controllers)
            {
                cont.HandleInput(this);
            }
            linkCommand.Update(gameTime);
            itemCommand.Update(gameTime);
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {

            GraphicsDevice.Clear(Color.CornflowerBlue);
            /*
            _spriteBatch.DrawString(font, "Credits", new Vector2(250, 300), Color.Black);
            _spriteBatch.DrawString(font, "Program made by: Krescens Kok", new Vector2(250, 320), Color.Black);
            _spriteBatch.DrawString(font, "Sprites from: http://www.mariouniverse.com/", new Vector2(250, 340), Color.Black);
            _spriteBatch.DrawString(font, "wp-content/img/sprites/nes/smb/mario.png", new Vector2(250, 360), Color.Black);

            */

            linkCommand.ExecuteCommand(this, spriteBatch);
            itemCommand.ExecuteCommand(this, spriteBatch);
            base.Draw(gameTime);
        }
    }
}
