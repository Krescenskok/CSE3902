﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items
{
    class ItemsCommand : ICommand
    {
        Items items;

        public ItemsCommand(SpriteBatch spriteBatch, bool goingForward, Game game)
        {
            this.items = new Items(spriteBatch, goingForward, game);
        }

        public void DoInit(Game game)
        {
            //throw new NotImplementedException();
        }

        public void ExecuteCommand(Game game, SpriteBatch spriteBatch)
        {
            items.ChangeState();
            //items.Draw(spriteBatch);
        }

        public void Update(GameTime gameTime)
        {
            items.Update();
        }
    }
}

