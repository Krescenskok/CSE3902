﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items
{
    public class Items
    {
        private SpriteBatch spriteBatch;
        private ItemsStateMachine state;
        private bool goingForward;

        private Vector2 currentLocation;
        
        public Items(SpriteBatch spriteBatch, bool goingForward, Game game)
        {
            this.spriteBatch = spriteBatch;
            this.goingForward = goingForward;

            currentLocation = new Vector2(game.GraphicsDevice.Viewport.Width / 2, game.GraphicsDevice.Viewport.Height / 2);

            state = new ItemsStateMachine(goingForward);
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            state.Draw(spriteBatch, gameTime, currentLocation);
        }

        public void ChangeState()
        {
            state.ChangeItem();
        }


        public void Update()
        {

            state.Update();
        }

        /*public void Map()
        {

        }

        public void Key()
        {

        }

        public void FancyKey()
        {

        }

        public void HeartContainer()
        {

        }

        public void TriforcePiece()
        {

        }

        public void WoodenBoomerang()
        {

        }

        public void Bow()
        {

        }

        public void FullHeart()
        {

        }

        public void HalfHeart()
        {

        }

        public void EmptyHeart()
        {

        }

        public void Rupee()
        {

        }

        public void Arrow()
        {

        }

        public void Bomb()
        {

        }

        public void Fairy()
        {

        }

        public void Clock()
        {

        }

        public void Meat()
        {

        }

        public void MagicBook()
        {

        }

        public void Recorder()
        {

        }*/
    }
}
