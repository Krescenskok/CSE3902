﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items.States
{
    public class Rupee : IItemsState
    {
        private Vector2 spriteLocation;
        private ISprite item;
        private int currentFrame;

        public Rupee(ISprite item)
        {
            spriteLocation = new Vector2(0, 63);
            this.item = item;
            currentFrame = 0;
        }

        public void Update()
        {
            currentFrame++;
            if (currentFrame == 5)
            {
                spriteLocation = new Vector2(10, 63);
            }
            else if (currentFrame == 10)
            {
                currentFrame = 0;
                spriteLocation = new Vector2(0, 63);
            }
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            item.Draw(spriteBatch, spriteLocation, 0);

        }

        public Vector2 GetLocation()
        {
            return spriteLocation;
        }

    }
}
