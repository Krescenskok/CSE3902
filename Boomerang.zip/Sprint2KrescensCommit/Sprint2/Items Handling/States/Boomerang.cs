﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items.States
{
    public class Boomerang : IItemsState
    {
        private Vector2 spriteLocation;
        private ISprite item;
        private int SHEET_LOCATION = 48;
        private int currentFrame;
        private int drawnFrame;
        private float angle;
        private int xPos = 100;
        private int yPos = 50;

        public Boomerang(ISprite item)
        {
            spriteLocation = new Vector2(xPos, yPos);
            this.item = item;
            currentFrame = 0;
            drawnFrame = SHEET_LOCATION;
            angle = 0;
        }

        public void Update()
        {
            if (yPos < 120)
            {
                yPos++;
            }
            else if (yPos < 20)
            {
                yPos++;
            }
            else
            {
                yPos--;
            }
            spriteLocation = new Vector2(xPos, yPos);

            angle += .01f;
            if (angle > 360)
            {
                angle = 0;
            }

        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            //item.Draw(spriteBatch, location, drawnFrame);
            item.DrawRotated(spriteBatch, spriteLocation, drawnFrame, angle);

        }

        public Vector2 GetLocation()
        {
            return spriteLocation;
        }

    }
}
