﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sprint0;

namespace Sprint0.Items
{

    public class ItemsSprite : ISprite
    {
        Texture2D texture;
        private int TOTAL_COLS = 8;
        private int TOTAL_ROWS = 7;
        private int width = 10;
        private int height = 20;

        public ItemsSprite(Texture2D texture)
        {
            this.texture = texture;          
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location, int currentFrame, Color color)
        {
            int width = texture.Width / TOTAL_COLS;
            int height = texture.Height / TOTAL_ROWS;

            int row = (int)((float)currentFrame / (float)TOTAL_COLS);
            int column = currentFrame % TOTAL_COLS;

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)location.X - width / 2, (int)location.Y - height / 2, 2 * width, 2 * height);

            spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, color);
        }
        
    }
}
