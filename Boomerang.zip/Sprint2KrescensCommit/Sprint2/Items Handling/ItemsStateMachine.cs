﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sprint0.Items.States;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Sprint0.Items
{
    public enum Item
    {
        Compass, Rupee, Map, Key, FancyKey, HeartContainer, TriforcePiece, WoodenBoomerang, Bow, FullHeart,
        HalfHeart, EmptyHeart, Arrow, Bomb, Fairy, Clock, Meat, MagicBook, Recorder
    };

    public class ItemsStateMachine
    {
        private ISprite itemSprite;
        private Vector2 currentLocation;
        private Item currentItem;
        private bool goingForward;
        private IDictionary<Item, IItemsState> itemToState = new Dictionary<Item, IItemsState>();
        private IItemsState currentState;


        public ItemsStateMachine(bool goingForward)
        {
            itemSprite = SpriteFactory.Instance.CreateItemsSprite();
            itemToState.Add(Item.Compass, new Compass(itemSprite));
            itemToState.Add(Item.Rupee, new Rupee(itemSprite));

            this.goingForward = goingForward;
            currentItem = Item.Compass;
            currentState = itemToState[Item.Compass];
        }

        public void Update()
        {
            currentState = itemToState[currentItem];
        }
        
        public void ChangeItem()
        {
            if (goingForward)
            {
                if (currentItem == Item.Rupee)
                {
                    currentItem = Item.Compass;
                }
                else
                {
                    currentItem++;
                }
            }
            else
            {
                if (currentItem == Item.Compass)
                {
                    currentItem = Item.Rupee;
                }
                else
                {
                    currentItem--;
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            currentState.Draw(spriteBatch, gameTime, location, (int) currentItem);
        }

    }
}
