﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sprint0.Items.States;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Sprint0.Items
{
    public enum Item
    {
        Compass, Rupee, Boomerang, Map, Key, FancyKey, HeartContainer, TriforcePiece, MagicalBoomerang, Heart, HalfHeart, EmptyHeart,
        MagicBook, Clock, Fairy, Ring, RedPotion, BluePotion, WoodenSword, SilverSword, Wand, Raft, Arrow, SilverArrow, Candle, BlueCandle,
        Bomb, FancySword, Shield, Meat, Bow, Bracelet, Recorder
    };
    public class ItemsStateMachine
    {
        private ISprite itemSprite;
       
        private Item currentItem;
        private bool goingForward;
        private IDictionary<Item, IItemsState> itemToState = new Dictionary<Item, IItemsState>();
        private IItemsState currentState;


        public ItemsStateMachine(bool goingForward)
        {
            itemSprite = SpriteFactory.Instance.CreateItemsSprite();

            itemToState.Add(Item.Compass, new Compass(itemSprite));
            itemToState.Add(Item.Rupee, new Rupee(itemSprite));
            itemToState.Add(Item.Boomerang, new Boomerang(itemSprite));

            this.goingForward = goingForward;
            currentItem = Item.Rupee;
            currentState = itemToState[Item.Boomerang];
        }


        public void Update()
        {
            currentState.Update();
        }
        
        public void ChangeItem()
        {
            if (goingForward)
            {
                if (currentItem == Item.Boomerang)
                {
                    currentItem = Item.Compass;
                }
                else
                {
                    currentItem++;
                }
            }
            else
            {
                if (currentItem == Item.Compass)
                {
                    currentItem = Item.Boomerang;
                }
                else
                {
                    currentItem--;
                }
            }

            currentState = itemToState[currentItem];
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            currentState.Draw(spriteBatch, currentState.GetLocation());
        }

    }
}
