﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint0.Items;
using Sprint0.Link;

namespace Sprint0
{
    public class KeyboardController: IController
    {

        IDictionary<Keys, ICommand> commandsList = new Dictionary<Keys, ICommand>();
        SpriteBatch spriteBatch;

        public KeyboardController(SpriteBatch spriteBatch, Game game)
        {
            this.spriteBatch = spriteBatch;
            commandsList.Add(Keys.Q, new QuitCommand());
            commandsList.Add(Keys.A, new LinkCommand(new LinkPlayer()));
            commandsList.Add(Keys.U, new ItemsCommand(spriteBatch, false, game));
            commandsList.Add(Keys.I, new ItemsCommand(spriteBatch, true, game));

        }

        public ICommand HandleInput(Game game)
        {
            var kstate = Keyboard.GetState().GetPressedKeys();

            foreach (var kvp in kstate)
            {
                if (commandsList.ContainsKey(kvp))
                {
                    commandsList[kvp].ExecuteCommand(game, spriteBatch);
                }
                

            }

            return null;

        }
    }
}
