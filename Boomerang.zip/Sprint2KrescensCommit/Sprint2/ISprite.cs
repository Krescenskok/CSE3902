﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    public interface ISprite
    {
        void Draw(SpriteBatch spriteBatch, Vector2 location, int currentFrame);

        void DrawRotated(SpriteBatch spriteBatch, Vector2 location, int currentFrame, float angle);
    }
}
