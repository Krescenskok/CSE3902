﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items
{
    class ItemsCommand : ICommand
    {
        Items items;

        public ItemsCommand(SpriteBatch spriteBatch, bool goingForward)
        {
            this.items = new Items(spriteBatch, goingForward);
        }

        public void DoInit(Game game)
        {
            //throw new NotImplementedException();
        }

        public void ExecuteCommand(Game game, SpriteBatch spriteBatch)
        {
            items.ChangeState();
            items.Draw();
        }

        public void Update(GameTime gameTime)
        {
            items.Update();
        }
    }
}

