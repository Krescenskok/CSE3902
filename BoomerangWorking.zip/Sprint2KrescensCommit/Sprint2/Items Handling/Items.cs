﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0.Items
{
    public class Items
    {
        private SpriteBatch spriteBatch;
        private ItemsStateMachine state;
        private ItemsStateMachine prevState;
        private bool goingForward;
        
        public Items(SpriteBatch spriteBatch, bool goingForward)
        {
            this.spriteBatch = spriteBatch;
            this.goingForward = goingForward;
            state = new ItemsStateMachine(goingForward);
            prevState = state;
        }

        public void Draw()
        {
            state.Draw(spriteBatch);
        }

        public void ChangeState()
        {
            state.ChangeItem();
        }

        public void Update()
        {
            state.Update();
        }

    }
}
