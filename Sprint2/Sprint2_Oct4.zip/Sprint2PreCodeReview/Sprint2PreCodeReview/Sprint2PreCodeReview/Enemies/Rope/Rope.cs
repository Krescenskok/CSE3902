﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint2.Enemies.Rope
{
    public class Rope
    {
    }
}
