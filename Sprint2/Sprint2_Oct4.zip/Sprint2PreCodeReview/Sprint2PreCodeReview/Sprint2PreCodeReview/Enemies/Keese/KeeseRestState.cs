﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint2
{
    public class KeeseRestState
    {
    }
}
