﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint2.Link
{
    public class LinkCommand : ICommand
    {

        LinkPlayer linkPlayer;
        String Key;

        public LinkCommand(LinkPlayer linkPlayer, String key)
        {
            this.linkPlayer = linkPlayer;
            this.Key = key;
        }

        public void DoInit(Game game)
        {
        }

        public void ExecuteCommand(Game game, GameTime gameTime, SpriteBatch spriteBatch)
        {
            linkPlayer.Draw(game, spriteBatch, gameTime );
        }

        public void Update(GameTime gameTime )
        {
            if ((Key.Equals("N") || (Key.Equals("Z"))))
            {
                linkPlayer.IsAttacking = true;
                linkPlayer.IsStopped = false;
            }



            else if ((Key.Equals("A")) || (Key.Equals("Left")))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingLeft();

            }
            else if ((Key.Equals("D")) || (Key.Equals("Right")))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingRight();

            }
            else if ((Key.Equals("W")) || (Key.Equals("Up")))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingUp();

            }
            else if ((Key.Equals("S")) || (Key.Equals("Down")))
            {
                linkPlayer.IsStopped = false;
                linkPlayer.MovingDown();
            }

            else if (Key.Equals("E"))
            {
                linkPlayer.IsDamaged = true;
            }
            else if ((Key.Equals("D1")) || (Key.Equals("NumPad1")))
            {
                linkPlayer.CurrentWeapon = Weapon.Sword;
            }

            else if ((Key.Equals("D2")) || (Key.Equals("NumPad2")))
            {
                linkPlayer.CurrentWeapon = Weapon.WoodenSword;
            }

            else if ((Key.Equals("D3")) || (Key.Equals("NumPad3")))
            {
                linkPlayer.CurrentWeapon = Weapon.MagicalRod;
            }

            else if (Key.Equals("R"))
            {
                linkPlayer.Stationary();
                linkPlayer.LocationInitialized = false;
            }
            linkPlayer.Update(gameTime);
        }
    }
}
